# Power BI Desktop Integration & Data Modeling Guide

This guide explains how to connect **Microsoft Power BI Desktop** to the social media engagement datasets and SQLite database created for **Swati Kumari's MCA Internship Project** (*Codec Technologies / IILM University*).

---

## 📌 Data Source Options

Power BI Desktop can connect to either of the following data sources created by the project pipeline:

1. **Option A: MS Excel Workbook** (Recommended)
   - Path: `data/social_media_engagement_analytics.xlsx`
   - Sheets: `Executive Summary`, `Cleaned Engagement Data`, `Optimal Posting Heatmap`, `Format & Category Benchmarks`

2. **Option B: SQLite Database**
   - Path: `data/social_media_engagement.db`
   - Connector: Power BI SQLite ODBC Driver or DirectQuery via Python script (`sqlite3`)

3. **Option C: Processed CSV Dataset**
   - Path: `data/cleaned_engagement_data.csv`

---

## 🛠️ Step-by-Step Connection in Power BI Desktop

1. **Open Power BI Desktop**.
2. Click **Get Data** -> **Excel workbook**.
3. Select `data/social_media_engagement_analytics.xlsx`.
4. In the **Navigator** window, check all 4 tables/sheets:
   - `Cleaned_Engagement_Data`
   - `Optimal_Posting_Heatmap`
   - `Format_Category_Benchmarks`
5. Click **Load** (or **Transform Data** to inspect in Power Query Editor).

---

## 📐 Data Model & Relationships

In the **Model View** tab of Power BI:
- Primary Table: `Cleaned_Engagement_Data` (`post_id`, `platform`, `category`, `format_type`, `day_of_week`, `posting_hour`, `views`, `likes`, `comments`, `shares`, `engagement_rate`, `posting_slot`)
- Dimensional Tables: `Format_Category_Benchmarks` linked via `platform` & `format_type`.

---

## 🧮 DAX Measures Setup

In Power BI Desktop, navigate to **Modeling** -> **New Measure** and paste the DAX definitions from `data/power_bi/power_bi_dax_measures.dax`:

```dax
Total Reach = SUM(Posts[views])
Total Engagements = SUM(Posts[likes]) + SUM(Posts[comments]) + SUM(Posts[shares])
Average Engagement Rate = AVERAGE(Posts[engagement_rate])
Virality Index = DIVIDE([Total Engagements], [Total Reach], 0) * 100
```

---

## 📊 Recommended Visual Layouts in Power BI Report

1. **Top KPI Cards**:
   - `Total Reach` (Card visual)
   - `Total Engagements` (Card visual)
   - `Average Engagement Rate` (Gauge visual with target 8.0%)
   - `Peak Posting Slot` (Card visual)

2. **2D Matrix Visual (Heatmap)**:
   - **Rows**: `day_of_week`
   - **Columns**: `posting_hour`
   - **Values**: `Average Engagement Rate`
   - **Conditional Formatting**: Background color scale (Light Blue to Dark Blue).

3. **Decomposition Tree & Bar Charts**:
   - Engagement rate breakdown by `Platform` -> `Format Type` -> `Category`.

4. **Slicers**:
   - Platform Filter (YouTube / Instagram / TikTok)
   - Category Filter (Tech / Education / Entertainment / Gaming)
