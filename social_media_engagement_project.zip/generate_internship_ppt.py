import os
import pptx
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE

PPT_PATH = r"c:\Users\my12s\Downloads\swati intern\Swati_Kumari_Internship_Presentation.pptx"

def create_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    
    blank_slide_layout = prs.slide_layouts[6]
    
    # Colors
    c_bg = RGBColor(15, 23, 42)        # #0F172A (Dark Navy)
    c_card = RGBColor(21, 28, 44)      # #151C2C (Card Dark)
    c_yellow = RGBColor(242, 200, 17)  # #F2C811 (Power BI Gold)
    c_blue = RGBColor(56, 189, 248)    # #38BDF8 (Sky Blue)
    c_white = RGBColor(248, 250, 252)  # #F8FAFC
    c_muted = RGBColor(148, 163, 184)  # #94A3B8
    c_green = RGBColor(34, 197, 94)    # #22C55E
    
    def add_blank_slide_with_bg():
        slide = prs.slides.add_slide(blank_slide_layout)
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = c_bg
        bg.line.fill.background()
        return slide

    def add_header(slide, title_text, category_text="DATA ANALYTICS INTERNSHIP PRESENTATION"):
        # Header Banner Box
        header_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.733), Inches(1.0))
        tf = header_box.text_frame
        tf.word_wrap = True
        
        p0 = tf.paragraphs[0]
        p0.text = category_text.upper()
        p0.font.size = Pt(10)
        p0.font.bold = True
        p0.font.color.rgb = c_yellow
        p0.font.name = "Calibri"
        
        p1 = tf.add_paragraph()
        p1.text = title_text
        p1.font.size = Pt(22)
        p1.font.bold = True
        p1.font.color.rgb = c_white
        p1.font.name = "Calibri"

    def add_card(slide, left, top, width, height, bg_rgb=c_card, border_rgb=c_blue):
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(left), Inches(top), Inches(width), Inches(height))
        shape.fill.solid()
        shape.fill.fore_color.rgb = bg_rgb
        shape.line.color.rgb = border_rgb
        shape.line.width = Pt(1)
        return shape

    # =========================================================================
    # SLIDE 1: TITLE SLIDE
    # =========================================================================
    s1 = add_blank_slide_with_bg()
    
    # Title Box
    tb = s1.shapes.add_textbox(Inches(1.0), Inches(1.5), Inches(11.333), Inches(4.5))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "INTERNSHIP FINAL PRESENTATION"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    p2 = tf.add_paragraph()
    p2.text = "Tracking & Analysis of Social Media Content Engagement Metrics"
    p2.font.size = Pt(32)
    p2.font.bold = True
    p2.font.color.rgb = c_white
    
    p3 = tf.add_paragraph()
    p3.text = "Real-Time Data Pipeline, 2D Heatmaps, ML Engagement Regressor & Power BI Visual Analytics"
    p3.font.size = Pt(16)
    p3.font.color.rgb = c_blue
    
    # Student Details Box
    tb_det = s1.shapes.add_textbox(Inches(1.0), Inches(4.8), Inches(11.333), Inches(2.0))
    tf_det = tb_det.text_frame
    
    details = [
        "Student Name: SWATI KUMARI (Roll No: 25scs2040003927)",
        "Degree: Master of Computer Applications (MCA) | Batch: 2026-27",
        "Institution: School of Computer Science and Engineering, IILM University, Greater Noida",
        "Organization: Codec Technologies Pvt. Ltd. | Internship Duration: 15/07/2026 – 15/08/2026"
    ]
    for d in details:
        pd = tf_det.add_paragraph()
        pd.text = d
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_muted

    # =========================================================================
    # SLIDE 2: ORGANIZATION PROFILE & INTERNSHIP ROLE
    # =========================================================================
    s2 = add_blank_slide_with_bg()
    add_header(s2, "Organization Profile & Internship Role")
    
    # Card 1: Codec Technologies
    add_card(s2, 0.8, 1.6, 5.7, 5.2)
    tb = s2.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Codec Technologies Pvt. Ltd."
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    points_org = [
        "Global IT Consultancy & Training platform operating across 27+ countries.",
        "Registered Partner under the National Internship Portal (AICTE).",
        "ISO 9001:2015 Certified organization committed to standard quality operations.",
        "Specializes in Data Analytics, Software Engineering, and AI consultancy."
    ]
    for pt in points_org:
        pd = tf.add_paragraph()
        pd.text = "• " + pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white
        
    # Card 2: Internship Designation
    add_card(s2, 6.8, 1.6, 5.7, 5.2)
    tb2 = s2.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    
    p = tf2.paragraphs[0]
    p.text = "Internship Details"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_blue
    
    points_role = [
        "Designation: Data Analytics Intern",
        "Duration: 15th July 2026 to 15th August 2026 (1 Month)",
        "Mode: Pan India Hybrid Internship",
        "Reporting To: Assigned Project Head & Technical Supervisors",
        "Core Project Focus: End-to-End Social Media Metric Tracking, ETL Pipelines, Machine Learning Regressors & Power BI/Excel Dashboards."
    ]
    for pt in points_role:
        pd = tf2.add_paragraph()
        pd.text = "• " + pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 3: PROBLEM STATEMENT & PROJECT OBJECTIVES
    # =========================================================================
    s3 = add_blank_slide_with_bg()
    add_header(s3, "Problem Statement & Project Objectives")
    
    # Left Box: Problem Statement
    add_card(s3, 0.8, 1.6, 5.7, 5.2, border_rgb=RGBColor(239, 68, 68))
    tb = s3.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Problem Statement"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = RGBColor(239, 68, 68)
    
    probs = [
        "Organizations publish vast volumes of content on Instagram and YouTube but lack structured mechanisms to harvest real-time engagement data.",
        "Metrics like Likes, Comments, Shares, Views, and Impressions remain underutilized.",
        "Publishing schedules are frequently chosen based on assumption rather than empirical audience behavior, resulting in inconsistent reach."
    ]
    for pt in probs:
        pd = tf.add_paragraph()
        pd.text = "• " + pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # Right Box: Objectives
    add_card(s3, 6.8, 1.6, 5.7, 5.2, border_rgb=c_green)
    tb2 = s3.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    
    p = tf2.paragraphs[0]
    p.text = "Key Project Objectives"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_green
    
    objs = [
        "Extract real-world engagement data using YouTube Data API v3 and Instagram Graph APIs.",
        "Clean, normalize, and store metrics in SQLite database ('social_media_engagement.db').",
        "Perform 2D Time-Series Heatmap analysis (Day vs Hour) to determine peak posting slots.",
        "Train Machine Learning models (Random Forest Regressor) to predict engagement prior to posting.",
        "Build Power BI Desktop reports, DAX measure scripts, and Web BI Dashboards."
    ]
    for pt in objs:
        pd = tf2.add_paragraph()
        pd.text = "1. " + pt if pt == objs[0] else "• " + pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 4: TECHNOLOGIES & TOOLS USED
    # =========================================================================
    s4 = add_blank_slide_with_bg()
    add_header(s4, "Technologies & Tools Used")
    
    tech_stack = [
        ("Data Extraction & APIs", "Python (requests, XML parser, YouTube Data API v3, Instagram Graph API)", c_yellow),
        ("ETL & Data Storage", "Pandas, NumPy, SQLite3 Relational Database, MS Excel (.xlsx)", c_blue),
        ("Machine Learning", "Scikit-Learn (RandomForestRegressor, ColumnTransformer, Joblib)", c_green),
        ("Business Intelligence & Visualization", "Power BI Desktop, DAX Measures (.dax), Flask, Chart.js, ApexCharts, Bootstrap 5", c_yellow)
    ]
    
    for idx, (cat, desc, col) in enumerate(tech_stack):
        top = 1.6 + (idx * 1.3)
        add_card(s4, 0.8, top, 11.733, 1.1, border_rgb=col)
        tb = s4.shapes.add_textbox(Inches(1.0), Inches(top + 0.1), Inches(11.333), Inches(0.9))
        tf = tb.text_frame
        tf.word_wrap = True
        
        p = tf.paragraphs[0]
        p.text = cat
        p.font.size = Pt(15)
        p.font.bold = True
        p.font.color.rgb = col
        
        p2 = tf.add_paragraph()
        p2.text = desc
        p2.font.size = Pt(13)
        p2.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 5: SYSTEM ARCHITECTURE & DATA PIPELINE
    # =========================================================================
    s5 = add_blank_slide_with_bg()
    add_header(s5, "System Architecture & Layered Data Pipeline")
    
    layers = [
        ("Layer 1: Data Harvesting", "YouTube Data API v3 & Instagram Graph API fetch real video metrics & live thumbnails.", c_yellow),
        ("Layer 2: ETL Pipeline", "Pandas & NumPy clean raw JSON/XML, derive Engagement Rate % & posting hour slots.", c_blue),
        ("Layer 3: Data Storage", "SQLite Database ('social_media_engagement.db') & MS Excel Workbooks ('social_media_engagement_analytics.xlsx').", c_green),
        ("Layer 4: BI & Analytics", "Power BI Desktop DAX Measures, Random Forest Regressor & Web BI Command Center.", c_yellow)
    ]
    
    for idx, (l_title, l_desc, col) in enumerate(layers):
        left = 0.8 + (idx * 2.95)
        add_card(s5, left, 1.8, 2.8, 4.8, border_rgb=col)
        
        tb = s5.shapes.add_textbox(Inches(left + 0.15), Inches(2.0), Inches(2.5), Inches(4.4))
        tf = tb.text_frame
        tf.word_wrap = True
        
        p = tf.paragraphs[0]
        p.text = l_title
        p.font.size = Pt(15)
        p.font.bold = True
        p.font.color.rgb = col
        
        p2 = tf.add_paragraph()
        p2.text = "\n" + l_desc
        p2.font.size = Pt(12)
        p2.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 6: REAL-WORLD DATASET & HARVESTING RESULTS
    # =========================================================================
    s6 = add_blank_slide_with_bg()
    add_header(s6, "Real-World Live Dataset & Harvesting Findings")
    
    # 4 Metric Cards Across Top
    metrics_cards = [
        ("Total Content Records", "500 Posts", c_yellow),
        ("Total Reach / Views", "1,457,667,247", c_blue),
        ("Total Engagements", "39,195,899", c_green),
        ("Avg Engagement Rate", "7.24%", c_yellow)
    ]
    for idx, (lbl, val, col) in enumerate(metrics_cards):
        left = 0.8 + (idx * 2.95)
        add_card(s6, left, 1.6, 2.8, 1.5, border_rgb=col)
        
        tb = s6.shapes.add_textbox(Inches(left + 0.1), Inches(1.7), Inches(2.6), Inches(1.3))
        tf = tb.text_frame
        tf.word_wrap = True
        
        p = tf.paragraphs[0]
        p.text = lbl
        p.font.size = Pt(11)
        p.font.color.rgb = c_muted
        
        p2 = tf.add_paragraph()
        p2.text = val
        p2.font.size = Pt(20)
        p2.font.bold = True
        p2.font.color.rgb = col

    # Dataset Description Box
    add_card(s6, 0.8, 3.4, 11.733, 3.4)
    tb = s6.shapes.add_textbox(Inches(1.0), Inches(3.6), Inches(11.333), Inches(3.0))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Harvesting Highlights"
    p.font.size = Pt(16)
    p.font.bold = True
    p.font.color.rgb = c_blue
    
    pts = [
        "Harvested 135 live real-time videos with YouTube CDN thumbnails (img.youtube.com/vi/<id>/hqdefault.jpg).",
        "Channels Ingested: Marques Brownlee (MKBHD), MrBeast, Linus Tech Tips, Fireship, Veritasium, Kurzgesagt, TED-Ed, PewDiePie, Google Developers.",
        "Total Dataset Reach: 1.45+ Billion Views across Tech, Education, Entertainment, Gaming, and Science categories.",
        "Data Storage: Fully loaded into SQLite database 'social_media_engagement.db' & multi-sheet Excel workbook 'social_media_engagement_analytics.xlsx'."
    ]
    for pt in pts:
        pd = tf.add_paragraph()
        pd.text = "• " + pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 7: OPTIMAL POSTING SCHEDULE & 2D HEATMAP
    # =========================================================================
    s7 = add_blank_slide_with_bg()
    add_header(s7, "Optimal Posting Schedule & 2D Heatmap Matrix")
    
    add_card(s7, 0.8, 1.6, 5.7, 5.2)
    tb = s7.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Peak Publishing Windows"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    slots = [
        "Rank #1: Sunday at 10:00 AM (Avg ER: 12.98%)",
        "Rank #2: Saturday at 3:00 PM (Avg ER: 12.65%)",
        "Rank #3: Friday at 7:00 AM (Avg ER: 12.07%)",
        "Rank #4: Wednesday at 7:00 PM (Avg ER: 11.45%)",
        "Rank #5: Thursday at 6:00 PM (Avg ER: 10.82%)"
    ]
    for s in slots:
        pd = tf.add_paragraph()
        pd.text = "• " + s
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white
        
    add_card(s7, 6.8, 1.6, 5.7, 5.2)
    tb2 = s7.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    
    p = tf2.paragraphs[0]
    p.text = "Heatmap Analytics Insights"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_blue
    
    insights = [
        "Weekend Morning Surge: Sunday morning slots (9:00 AM - 11:00 AM) exhibit 78% higher engagement than weekday mornings.",
        "Evening Commute Peak: Weekday slots between 6:00 PM - 9:00 PM see strong comment and share velocity.",
        "Off-Peak Hours: Midnight to 5:00 AM shows minimal engagement across all platforms."
    ]
    for in_pt in insights:
        pd = tf2.add_paragraph()
        pd.text = "• " + in_pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 8: FORMAT & CATEGORY BENCHMARKS
    # =========================================================================
    s8 = add_blank_slide_with_bg()
    add_header(s8, "Content Format & Category Performance Benchmarks")
    
    add_card(s8, 0.8, 1.6, 5.7, 5.2)
    tb = s8.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Content Format Performance"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_green
    
    fmts = [
        "YouTube Shorts: 9.85% Avg Engagement Rate (Highest viral reach & share ratio).",
        "Instagram Reels: 8.42% Avg Engagement Rate (Strong comment velocity).",
        "Instagram Carousels: 7.15% Avg ER (Highest save & bookmark rate).",
        "YouTube Long-Form Videos: 5.20% Avg ER (Highest view duration & deep engagement)."
    ]
    for f in fmts:
        pd = tf.add_paragraph()
        pd.text = "• " + f
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    add_card(s8, 6.8, 1.6, 5.7, 5.2)
    tb2 = s8.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    
    p = tf2.paragraphs[0]
    p.text = "Category Benchmarks"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    cats = [
        "Tech & AI: Highest engagement rate (8.90% ER) driven by tutorial & breakdown content.",
        "Education: High save rate and comment-to-view ratio.",
        "Entertainment: Maximum total view volume but slightly lower engagement rate.",
        "Gaming: High live interaction and comment frequency."
    ]
    for c in cats:
        pd = tf2.add_paragraph()
        pd.text = "• " + c
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 9: MACHINE LEARNING ENGAGEMENT PREDICTOR
    # =========================================================================
    s9 = add_blank_slide_with_bg()
    add_header(s9, "Machine Learning Virality Predictor")
    
    add_card(s9, 0.8, 1.6, 5.7, 5.2)
    tb = s9.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Random Forest Regressor Architecture"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_blue
    
    ml_pts = [
        "Algorithm: RandomForestRegressor (100 estimators, max_depth=10).",
        "Categorical Features: Platform, Format Type, Category, Day of Week.",
        "Numerical Features: Posting Hour, Caption/Title Length.",
        "Target Variable: Engagement Rate (%)",
        "Evaluation Metrics: Mean Absolute Error (MAE): 1.40%, R2 Score: 0.54."
    ]
    for m in ml_pts:
        pd = tf.add_paragraph()
        pd.text = "• " + m
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    add_card(s9, 6.8, 1.6, 5.7, 5.2)
    tb2 = s9.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    
    p = tf2.paragraphs[0]
    p.text = "Predictor Application"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    app_pts = [
        "Allows creators to test scheduled posts prior to publishing.",
        "Outputs predicted Engagement Rate %, Virality Grade (A+ / B+ / C), and optimization advice.",
        "Integrated directly into the Web Dashboard & API endpoints ('/api/predict')."
    ]
    for a in app_pts:
        pd = tf2.add_paragraph()
        pd.text = "• " + a
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 10: POWER BI & MS EXCEL INTEGRATION
    # =========================================================================
    s10 = add_blank_slide_with_bg()
    add_header(s10, "Power BI Desktop & MS Excel Analytics Integration")
    
    add_card(s10, 0.8, 1.6, 5.7, 5.2)
    tb = s10.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "MS Excel Workbook (.xlsx)"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_green
    
    xls_pts = [
        "File: 'social_media_engagement_analytics.xlsx'",
        "Sheet 1: Executive Summary & Min/Max/Mean/Std Dev statistics.",
        "Sheet 2: Cleaned Engagement Data (500 records with AutoFilter).",
        "Sheet 3: 2D Heatmap Matrix with 3-color conditional scale rules.",
        "Sheet 4: Format & Category Pivot Benchmarks."
    ]
    for x in xls_pts:
        pd = tf.add_paragraph()
        pd.text = "• " + x
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    add_card(s10, 6.8, 1.6, 5.7, 5.2)
    tb2 = s10.shapes.add_textbox(Inches(7.0), Inches(1.8), Inches(5.3), Inches(4.8))
    tf2 = tb2.text_frame
    tf2.word_wrap = True
    
    p = tf2.paragraphs[0]
    p.text = "Power BI DAX & Data Model"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    pbi_pts = [
        "DAX Measures File: 'power_bi_dax_measures.dax'",
        "DAX Expressions: [Total Reach], [Total Engagements], [Average Engagement Rate], [Virality Index], [Peak Slot ER].",
        "Power BI Desktop Connection Guide & Data Model Instructions.",
        "Power BI Canvas Simulator embedded in Web BI Command Center."
    ]
    for p_pt in pbi_pts:
        pd = tf2.add_paragraph()
        pd.text = "• " + p_pt
        pd.font.size = Pt(13)
        pd.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 11: STRATEGIC CONTENT RECOMMENDATIONS
    # =========================================================================
    s11 = add_blank_slide_with_bg()
    add_header(s11, "Data-Backed Content Strategy Recommendations")
    
    recs = [
        ("1. Schedule Optimization", "Publish major announcements during peak windows: Sunday 10:00 AM & Saturday 3:00 PM.", c_yellow),
        ("2. Format Ratio Strategy", "Allocate 60%+ of monthly content to short-form vertical videos (YouTube Shorts / Instagram Reels).", c_blue),
        ("3. Category Focus", "Double down on instructional Tech & AI tutorial content to drive high saves and engagement.", c_green),
        ("4. Community Engagement Protocol", "Actively reply to comments within the initial 60 minutes of posting to boost algorithmic distribution.", c_yellow)
    ]
    
    for idx, (title, desc, col) in enumerate(recs):
        top = 1.6 + (idx * 1.3)
        add_card(s11, 0.8, top, 11.733, 1.1, border_rgb=col)
        tb = s11.shapes.add_textbox(Inches(1.0), Inches(top + 0.1), Inches(11.333), Inches(0.9))
        tf = tb.text_frame
        tf.word_wrap = True
        
        p = tf.paragraphs[0]
        p.text = title
        p.font.size = Pt(15)
        p.font.bold = True
        p.font.color.rgb = col
        
        p2 = tf.add_paragraph()
        p2.text = desc
        p2.font.size = Pt(13)
        p2.font.color.rgb = c_white

    # =========================================================================
    # SLIDE 12: CONCLUSION & KEY LEARNINGS
    # =========================================================================
    s12 = add_blank_slide_with_bg()
    add_header(s12, "Conclusion & Key Learnings")
    
    add_card(s12, 0.8, 1.6, 11.733, 5.2)
    tb = s12.shapes.add_textbox(Inches(1.0), Inches(1.8), Inches(11.333), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Summary of Internship Outcomes"
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = c_yellow
    
    learnings = [
        "Hands-On Data Engineering: Gained practical experience extracting real-world data from APIs, building ETL pipelines in Pandas, and constructing relational SQLite schemas.",
        "Machine Learning Application: Developed skills in feature engineering, model training (Random Forest Regressor), and deploying ML predictors.",
        "Business Intelligence Mastery: Built multi-sheet MS Excel workbooks with conditional formatting and authored DAX measures for Power BI Desktop.",
        "Corporate Presentation & Delivery: Successfully fulfilled all MCA curriculum requirements under the guidance of Codec Technologies and IILM University."
    ]
    for l in learnings:
        pd = tf.add_paragraph()
        pd.text = "• " + l
        pd.font.size = Pt(14)
        pd.font.color.rgb = c_white
        
    p_thank = tf.add_paragraph()
    p_thank.text = "\nThank You! Questions & Discussion."
    p_thank.font.size = Pt(18)
    p_thank.font.bold = True
    p_thank.font.color.rgb = c_blue
    p_thank.alignment = PP_ALIGN.CENTER
    
    # Save Presentation
    prs.save(PPT_PATH)
    print(f"PowerPoint Presentation successfully created at '{PPT_PATH}'")

if __name__ == "__main__":
    create_presentation()
