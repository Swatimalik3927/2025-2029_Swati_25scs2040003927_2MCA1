import os
import sqlite3
import pandas as pd
import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule

EXCEL_PATH = "data/social_media_engagement_analytics.xlsx"
CLEANED_CSV_PATH = "data/cleaned_engagement_data.csv"
HEATMAP_CSV_PATH = "data/optimal_posting_times.csv"

def build_formatted_excel():
    print(f"[ExcelBuilder] Generating multi-sheet Excel workbook at '{EXCEL_PATH}'...")
    
    # 1. Load Data
    if os.path.exists(CLEANED_CSV_PATH):
        df = pd.read_csv(CLEANED_CSV_PATH)
    else:
        from src.etl_pipeline import run_etl
        df = run_etl()
        
    if os.path.exists(HEATMAP_CSV_PATH):
        heatmap_df = pd.read_csv(HEATMAP_CSV_PATH, index_col=0)
    else:
        from src.analytics_engine import generate_posting_heatmap
        heatmap_df = generate_posting_heatmap(df)

    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    # Styles
    navy_header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    blue_kpi_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    title_font = Font(name="Calibri", size=16, bold=True, color="1F4E78")
    subtitle_font = Font(name="Calibri", size=11, italic=True, color="595959")
    kpi_val_font = Font(name="Calibri", size=16, bold=True, color="1F4E78")
    kpi_lbl_font = Font(name="Calibri", size=10, bold=True, color="595959")
    regular_font = Font(name="Calibri", size=11)
    bold_font = Font(name="Calibri", size=11, bold=True)
    thin_border = Border(
        left=Side(style='thin', color='D9D9D9'),
        right=Side(style='thin', color='D9D9D9'),
        top=Side(style='thin', color='D9D9D9'),
        bottom=Side(style='thin', color='D9D9D9')
    )

    # =========================================================================
    # SHEET 1: EXECUTIVE SUMMARY
    # =========================================================================
    ws1 = wb.create_sheet(title="Executive Summary")
    ws1.views.sheetView[0].showGridLines = True
    
    ws1.cell(row=2, column=2, value="Social Media Engagement Analytics - Executive Summary").font = title_font
    ws1.cell(row=3, column=2, value="Internship Project Report | Codec Technologies (Swati Kumari)").font = subtitle_font
    
    # KPI Cards Block
    total_posts = len(df)
    total_views = int(df['views'].sum())
    total_engagements = int(df['total_engagements'].sum())
    avg_er = float(round(df['engagement_rate'].mean(), 2))
    
    kpis = [
        ("Total Content Posts", f"{total_posts:,}"),
        ("Total Reach / Views", f"{total_views:,}"),
        ("Total Engagements", f"{total_engagements:,}"),
        ("Average Engagement Rate", f"{avg_er}%"),
        ("Peak Posting Window", "Sunday @ 10:00 AM")
    ]
    
    for idx, (lbl, val) in enumerate(kpis):
        col = 2 + (idx * 2)
        ws1.merge_cells(start_row=5, start_column=col, end_row=5, end_column=col+1)
        ws1.merge_cells(start_row=6, start_column=col, end_row=6, end_column=col+1)
        
        c_lbl = ws1.cell(row=5, column=col, value=lbl)
        c_lbl.font = kpi_lbl_font
        c_lbl.alignment = Alignment(horizontal="center", vertical="center")
        c_lbl.fill = blue_kpi_fill
        
        c_val = ws1.cell(row=6, column=col, value=val)
        c_val.font = kpi_val_font
        c_val.alignment = Alignment(horizontal="center", vertical="center")
        c_val.fill = blue_kpi_fill

    # Summary Statistics Table
    ws1.cell(row=9, column=2, value="Metric Summary Statistics").font = Font(name="Calibri", size=13, bold=True, color="1F4E78")
    
    stats_headers = ["Metric", "Mean", "Median", "Min", "Max", "Std Dev"]
    for c_idx, h in enumerate(stats_headers, start=2):
        cell = ws1.cell(row=10, column=c_idx, value=h)
        cell.fill = navy_header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        
    numeric_cols = ['views', 'likes', 'comments', 'shares', 'engagement_rate']
    for r_idx, col_name in enumerate(numeric_cols, start=11):
        s_mean = df[col_name].mean()
        s_med = df[col_name].median()
        s_min = df[col_name].min()
        s_max = df[col_name].max()
        s_std = df[col_name].std()
        
        ws1.cell(row=r_idx, column=2, value=col_name.replace('_', ' ').title()).font = bold_font
        ws1.cell(row=r_idx, column=3, value=round(s_mean, 2)).number_format = '#,##0.00'
        ws1.cell(row=r_idx, column=4, value=round(s_med, 2)).number_format = '#,##0.00'
        ws1.cell(row=r_idx, column=5, value=round(s_min, 2)).number_format = '#,##0.00'
        ws1.cell(row=r_idx, column=6, value=round(s_max, 2)).number_format = '#,##0.00'
        ws1.cell(row=r_idx, column=7, value=round(s_std, 2)).number_format = '#,##0.00'

    # Auto-adjust columns
    for col in ws1.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws1.column_dimensions[col_letter].width = max(max_len + 3, 12)

    # =========================================================================
    # SHEET 2: CLEANED ENGAGEMENT DATA
    # =========================================================================
    ws2 = wb.create_sheet(title="Cleaned Engagement Data")
    ws2.views.sheetView[0].showGridLines = True
    
    # Write Headers
    cols = list(df.columns)
    for c_idx, col_name in enumerate(cols, start=1):
        cell = ws2.cell(row=1, column=c_idx, value=col_name.replace('_', ' ').title())
        cell.fill = navy_header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        
    # Write Rows
    for r_idx, row in enumerate(df.itertuples(index=False), start=2):
        for c_idx, val in enumerate(row, start=1):
            cell = ws2.cell(row=r_idx, column=c_idx, value=val)
            cell.font = regular_font
            cell.border = thin_border
            
            col_header = cols[c_idx-1]
            if col_header in ['views', 'likes', 'comments', 'shares', 'impressions', 'total_engagements']:
                cell.number_format = '#,##0'
                cell.alignment = Alignment(horizontal="right")
            elif 'pct' in col_header or col_header == 'engagement_rate':
                cell.number_format = '0.00'
                cell.alignment = Alignment(horizontal="right")

    # Add AutoFilter
    ws2.auto_filter.ref = ws2.dimensions
    
    for col in ws2.columns:
        max_len = max(len(str(cell.value or '')) for cell in col[:50])
        col_letter = get_column_letter(col[0].column)
        ws2.column_dimensions[col_letter].width = min(max(max_len + 3, 12), 40)

    # =========================================================================
    # SHEET 3: OPTIMAL POSTING HEATMAP
    # =========================================================================
    ws3 = wb.create_sheet(title="Optimal Posting Heatmap")
    ws3.views.sheetView[0].showGridLines = True
    
    ws3.cell(row=2, column=2, value="2D Posting Time Engagement Rate (%) Heatmap Matrix").font = title_font
    ws3.cell(row=3, column=2, value="Day of Week (Rows) vs Hour of Day (00:00 - 23:00 Columns)").font = subtitle_font
    
    # Write Matrix Headers
    ws3.cell(row=5, column=2, value="Day of Week").fill = navy_header_fill
    ws3.cell(row=5, column=2).font = header_font
    
    for h in range(24):
        cell = ws3.cell(row=5, column=3+h, value=f"{h:02d}:00")
        cell.fill = navy_header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")
        
    days = list(heatmap_df.index)
    for r_idx, day in enumerate(days, start=6):
        c_day = ws3.cell(row=r_idx, column=2, value=day)
        c_day.font = bold_font
        c_day.fill = blue_kpi_fill
        
        for c_idx in range(24):
            val = float(heatmap_df.iloc[r_idx-6, c_idx])
            cell = ws3.cell(row=r_idx, column=3+c_idx, value=val)
            cell.font = regular_font
            cell.number_format = '0.00'
            cell.alignment = Alignment(horizontal="right")
            cell.border = thin_border
            
    # Conditional formatting color scale for heatmap (Light blue to dark blue)
    color_scale = ColorScaleRule(
        start_type='num', start_value=2.0, start_color='F2F2F2',
        mid_type='num', mid_value=7.0, mid_color='BDD7EE',
        end_type='num', end_value=15.0, end_color='2F5597'
    )
    ws3.conditional_formatting.add("C6:Z12", color_scale)

    for col in ws3.columns:
        col_letter = get_column_letter(col[0].column)
        ws3.column_dimensions[col_letter].width = 10 if col[0].column > 2 else 16

    # =========================================================================
    # SHEET 4: FORMAT & CATEGORY BENCHMARKS
    # =========================================================================
    ws4 = wb.create_sheet(title="Format & Category Benchmarks")
    ws4.views.sheetView[0].showGridLines = True
    
    ws4.cell(row=2, column=2, value="Performance Benchmarks by Platform, Format & Category").font = title_font
    
    # Format Summary Table
    ws4.cell(row=4, column=2, value="Performance by Content Format").font = Font(name="Calibri", size=13, bold=True, color="1F4E78")
    fmt_df = df.groupby(['platform', 'format_type']).agg(
        total_posts=('post_id', 'count'),
        avg_views=('views', 'mean'),
        avg_likes=('likes', 'mean'),
        avg_comments=('comments', 'mean'),
        avg_engagement_rate=('engagement_rate', 'mean')
    ).reset_index().round(2)
    
    fmt_cols = list(fmt_df.columns)
    for c_idx, col_name in enumerate(fmt_cols, start=2):
        cell = ws4.cell(row=5, column=c_idx, value=col_name.replace('_', ' ').title())
        cell.fill = navy_header_fill
        cell.font = header_font
        
    for r_idx, row in enumerate(fmt_df.itertuples(index=False), start=6):
        for c_idx, val in enumerate(row, start=2):
            cell = ws4.cell(row=r_idx, column=c_idx, value=val)
            cell.font = regular_font
            cell.border = thin_border
            if isinstance(val, (int, float)):
                cell.number_format = '#,##0.00'

    for col in ws4.columns:
        col_letter = get_column_letter(col[0].column)
        ws4.column_dimensions[col_letter].width = 18

    # Save Workbook
    os.makedirs(os.path.dirname(EXCEL_PATH), exist_ok=True)
    wb.save(EXCEL_PATH)
    print(f"[ExcelBuilder] Multi-sheet Excel workbook successfully saved to '{EXCEL_PATH}'")

if __name__ == "__main__":
    build_formatted_excel()
