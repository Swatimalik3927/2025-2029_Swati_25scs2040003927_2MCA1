import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def create_element(name):
    return OxmlElement(name)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def generate_report():
    doc = docx.Document()
    
    # Set Margins as per Guidelines (Left 1.5 in, Right 1.0 in, Top 0.75 in, Bottom 1.0 in)
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.75)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.5)
        section.right_margin = Inches(1.0)
        
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    font.color.rgb = RGBColor(0, 0, 0)
    
    # ----------------------------------------------------
    # COVER PAGE
    # ----------------------------------------------------
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("INTERNSHIP REPORT\nOn\nTRACKING AND ANALYSIS OF SOCIAL MEDIA CONTENT ENGAGEMENT METRICS\n\n")
    run.font.size = Pt(16)
    run.font.bold = True
    
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = p2.add_run("Submitted To\nSchool of Computer Science and Engineering\nIILM University, Greater Noida, U.P.\n\nIn partial fulfilment of the requirement for the award of the degree of\nMASTER OF COMPUTER APPLICATIONS (MCA)\n\n")
    run2.font.size = Pt(12)
    
    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run3 = p3.add_run("By:\nRoll Number of Student: 25scs2040003927\nName of Student: SWATI KUMARI\nBatch: 2026-27\n\n")
    run3.font.size = Pt(12)
    run3.font.bold = True
    
    doc.add_page_break()
    
    # ----------------------------------------------------
    # CANDIDATE'S DECLARATION
    # ----------------------------------------------------
    h = doc.add_paragraph()
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = h.add_run("CANDIDATE'S DECLARATION\n")
    r.font.size = Pt(14)
    r.font.bold = True
    
    p = doc.add_paragraph(
        "I, Swati Kumari, do hereby declare that the internship report titled 'Tracking and Analysis of Social Media Content Engagement Metrics' has been completed by me to fulfil the requirement for the award of the degree of Master of Computer Applications (MCA). All the references have been quoted and I have not taken as such any material from any other source. I affirm that this report is my own work and has not been submitted to any other institute for any degree/diploma requirement, and further I shall be solely responsible for any kind of copyright violation in this regard."
    )
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    p_sig = doc.add_paragraph("\n\nSignature: ____________________\nStudent Name: Swati Kumari\nRoll No.: 25scs2040003927")
    p_sig.paragraph_format.line_spacing = 1.5
    
    doc.add_page_break()
    
    # ----------------------------------------------------
    # ACKNOWLEDGEMENT
    # ----------------------------------------------------
    h = doc.add_paragraph()
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = h.add_run("ACKNOWLEDGEMENT\n")
    r.font.size = Pt(14)
    r.font.bold = True
    
    p = doc.add_paragraph(
        "I am using this opportunity to express my gratitude to everyone who supported me throughout the Internship Program at Codec Technologies. I am thankful for their aspiring guidance, invaluably constructive criticism and friendly advice during this work. I am sincerely grateful to them for sharing their truthful and illuminating views on a number of issues related to this project.\n\n"
        "I would like to thank Dr. Anurag Shrivastava and the entire team at Codec Technologies for providing me the opportunity to work as a Data Analytics Intern and for their continuous support and mentorship throughout the internship period from 15/07/2026 to 15/08/2026.\n\n"
        "I would also like to thank the School of Computer Science and Engineering, IILM University, Greater Noida, for giving me the platform and encouragement to undertake this internship as part of my academic curriculum.\n\n"
        "I express my gratitude to my parents for their blessings and constant support."
    )
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    p_sig = doc.add_paragraph("\n\nSignature: ____________________\nStudent Name: Swati Kumari\nRoll No.: 25scs2040003927")
    p_sig.paragraph_format.line_spacing = 1.5
    
    doc.add_page_break()
    
    # ----------------------------------------------------
    # CHAPTER 4: PROJECT DESCRIPTION
    # ----------------------------------------------------
    h = doc.add_paragraph()
    r = h.add_run("CHAPTER 4: PROJECT DESCRIPTION")
    r.font.size = Pt(14)
    r.font.bold = True
    
    sections_text = [
        ("4.1 Introduction", "In the current digital era, social media platforms such as Instagram and YouTube have become primary channels through which brands and creators connect with their audiences. Engagement metrics such as likes, comments, shares, views, and impressions provide quantifiable insights into viewer behavior and content quality. This project focuses on designing an end-to-end data pipeline to collect real-world social media metrics via official APIs, process raw engagement data, build predictive machine learning models, and visualize optimal posting times through interactive BI dashboards."),
        ("4.2 Organization Profile", "Codec Technologies Pvt. Ltd. is a global technology consultancy and training platform delivering IT services across 27+ countries. Codec Technologies is registered on the National Internship Portal (AICTE) and is ISO 9001:2015 certified."),
        ("4.3 Problem Statement", "Organizations publish large volumes of digital content on platforms like YouTube and Instagram but lack structured data mechanisms to analyze engagement metrics in real time. Publishing decisions are often made based on assumption rather than empirical audience data, resulting in suboptimal reach."),
        ("4.4 Project Objectives", "1. To extract real-world video and post engagement data using YouTube Data API v3 and social Graph APIs.\n2. To clean, normalize, and store engagement metrics in a relational SQLite database.\n3. To perform 2D time-series heatmap analysis (Posting Hour vs Day of Week) to determine peak publishing slots.\n4. To train Machine Learning models (Random Forest Regressor) to forecast post engagement rates prior to publishing.\n5. To build an interactive Web BI Dashboard for real-time visualization and decision support."),
        ("4.5 Scope of the Project", "The project covers post-level and video-level engagement tracking across YouTube, Instagram, and TikTok, time-slot heatmap analysis, machine learning forecasting, and dashboard visualization. Paid advertising campaigns are outside the project scope."),
        ("4.6 Technologies and Tools Used", "• Data Extraction: Python (requests, xml.etree, YouTube Data API v3)\n• Data Pipeline & Storage: Pandas, NumPy, SQLite3 Database\n• Machine Learning: Scikit-learn (RandomForestRegressor, ColumnTransformer)\n• Data Visualization: Flask, HTML5, Chart.js, ApexCharts, Bootstrap 5\n• Version Control: Git & GitHub"),
        ("4.7 System Architecture", "The architecture follows a four-layered pipeline:\n1. Data Collection Layer: Fetches real-time video metrics and thumbnails from online channels.\n2. Data Processing (ETL) Layer: Calculates Engagement Rate %, extracts posting hours and days.\n3. Data Storage Layer: Stores clean records in SQLite database 'social_media_engagement.db'.\n4. Presentation Layer: Serves interactive visual analytics on web dashboard at http://127.0.0.1:5000."),
        ("4.8 Methodology", "Requirement analysis -> API integration -> Data harvesting -> ETL transformation -> Heatmap analytics -> Random Forest model training -> Web dashboard deployment -> Empirical verification."),
        ("4.9 Expected Outcomes", "• Clean structured dataset of 500+ social media posts.\n• SQLite database with normalized relational tables.\n• 2D heatmap matrix identifying peak engagement times.\n• Trained Random Forest model achieving MAE 1.4% and R2 Score 0.54.\n• Interactive Web BI Dashboard with real YouTube channel search."),
        ("4.10 Certificates of Completion and Proof", "Offer Letter and Internship Completion Certificate issued by Codec Technologies for the period 15/07/2026 to 15/08/2026.")
    ]
    
    for title, text in sections_text:
        hp = doc.add_paragraph()
        hr = hp.add_run(title)
        hr.font.size = Pt(12)
        hr.font.bold = True
        
        tp = doc.add_paragraph(text)
        tp.paragraph_format.line_spacing = 1.5
        tp.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        
    # Add Empirical Results Table
    doc.add_paragraph().add_run("\nTable 4.1: Real Harvested Data Summary").font.bold = True
    table = doc.add_table(rows=5, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers = ["Metric Category", "Harvested Value", "Status"]
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = h
        hdr_cells[i].paragraphs[0].runs[0].font.bold = True
        
    data_rows = [
        ("Total Posts Processed", "500 Records", "Verified"),
        ("Total Reach / Views", "1,457,667,247 Views", "Verified"),
        ("Total Engagements", "39,195,899 Likes/Comments", "Verified"),
        ("Peak Posting Window", "Sunday at 10:00 AM", "Optimal Slot")
    ]
    for r_idx, row in enumerate(data_rows):
        row_cells = table.rows[r_idx + 1].cells
        for c_idx, val in enumerate(row):
            row_cells[c_idx].text = val
            
    doc.add_page_break()
    
    # ----------------------------------------------------
    # BIBLIOGRAPHY / REFERENCES
    # ----------------------------------------------------
    h = doc.add_paragraph()
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = h.add_run("CHAPTER 5: BIBLIOGRAPHY / REFERENCES\n")
    r.font.size = Pt(14)
    r.font.bold = True
    
    refs = [
        "1. Google Developers. YouTube Data API v3 Documentation. Available at: https://developers.google.com/youtube/v3",
        "2. Meta for Developers. Instagram Graph API Documentation. Available at: https://developers.facebook.com/docs/instagram-api/",
        "3. McKinney, W. Python for Data Analysis: Data Wrangling with pandas, NumPy, and Jupyter. O'Reilly Media.",
        "4. Pedregosa, F., et al. Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825-2830.",
        "5. Grus, J. Data Science from Scratch: First Principles with Python. O'Reilly Media.",
        "6. Codec Technologies. Internship Completion Certificate and Performance Appraisal, 2026."
    ]
    
    for ref in refs:
        p = doc.add_paragraph(ref)
        p.paragraph_format.line_spacing = 1.0
        p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
        
    out_path = r"c:\Users\my12s\Downloads\swati intern\Swati_Kumari_Internship_Report_Compliant_2026-27.docx"
    doc.save(out_path)
    print(f"Compliant Report DOCX saved successfully to '{out_path}'")

if __name__ == "__main__":
    generate_report()
