import os
import sys
import argparse
import pandas as pd
from flask import Flask, render_template, jsonify, request, send_file, Response

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.etl_pipeline import run_etl
from src.analytics_engine import run_analytics_suite, get_db_connection, calculate_kpis, generate_posting_heatmap, get_best_posting_slots, analyze_format_performance, analyze_category_performance
from src.ml_predictor import predict_post_engagement, train_engagement_model
from src.recommendation_engine import generate_recommendations
from src.data_collector import fetch_youtube_channel_data, POPULAR_CHANNELS
from build_excel_workbook import build_formatted_excel, EXCEL_PATH

app = Flask(__name__)

CLEANED_CSV_PATH = "data/cleaned_engagement_data.csv"
if not os.path.exists(CLEANED_CSV_PATH):
    run_etl()

if not os.path.exists(EXCEL_PATH):
    build_formatted_excel()

def get_current_df():
    if os.path.exists(CLEANED_CSV_PATH):
        return pd.read_csv(CLEANED_CSV_PATH)
    else:
        return run_etl()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/overview')
def get_overview():
    df = get_current_df()
    analytics = run_analytics_suite(df)
    recs = generate_recommendations(analytics)
    
    return jsonify({
        "kpis": analytics['kpis'],
        "top_slots": analytics['top_slots'],
        "formats": analytics['formats'],
        "categories": analytics['categories'],
        "recommendations": recs
    })

@app.route('/api/heatmap')
def get_heatmap():
    df = get_current_df()
    heatmap_matrix = generate_posting_heatmap(df)
    
    days = list(heatmap_matrix.index)
    hours = [f"{h:02d}:00" for h in range(24)]
    values = heatmap_matrix.values.tolist()
    
    return jsonify({
        "days": days,
        "hours": hours,
        "z_matrix": values
    })

@app.route('/api/posts')
def get_posts():
    df = get_current_df()
    
    platform = request.args.get('platform')
    category = request.args.get('category')
    format_type = request.args.get('format_type')
    search = request.args.get('search')
    
    if platform and platform != 'All':
        df = df[df['platform'] == platform]
    if category and category != 'All':
        df = df[df['category'] == category]
    if format_type and format_type != 'All':
        df = df[df['format_type'] == format_type]
    if search:
        df = df[df['title'].str.contains(search, case=False, na=False)]
        
    posts = df.sort_values(by='engagement_rate', ascending=False).head(100).to_dict(orient='records')
    return jsonify({
        "total_matches": len(df),
        "posts": posts
    })

@app.route('/api/live-youtube')
def fetch_live_youtube():
    channel_query = request.args.get('channel', 'MKBHD')
    
    channel_id = POPULAR_CHANNELS.get(channel_query, None)
    if not channel_id:
        channel_id = 'UCBJycsmduvYEL83R_U4JriQ'
        
    live_videos = fetch_youtube_channel_data(channel_query, channel_id)
    
    if live_videos:
        live_df = pd.DataFrame(live_videos)
        from src.etl_pipeline import clean_and_transform
        cleaned_live = clean_and_transform(live_df)
        records = cleaned_live.to_dict(orient='records')
        return jsonify({
            "status": "success",
            "channel": channel_query,
            "count": len(records),
            "videos": records
        })
    else:
        return jsonify({
            "status": "error",
            "message": f"Could not fetch live data for channel '{channel_query}'"
        }), 400

@app.route('/api/predict', methods=['POST'])
def predict_engagement():
    data = request.get_json() or {}
    platform = data.get('platform', 'YouTube')
    category = data.get('category', 'Tech')
    format_type = data.get('format_type', 'YouTube Short')
    posting_hour = int(data.get('posting_hour', 18))
    day_of_week = data.get('day_of_week', 'Wednesday')
    title = data.get('title', 'Exciting new update!')
    
    result = predict_post_engagement(platform, category, format_type, posting_hour, day_of_week, title)
    return jsonify(result)

@app.route('/api/export-csv')
def export_csv():
    if os.path.exists(CLEANED_CSV_PATH):
        return send_file(os.path.abspath(CLEANED_CSV_PATH), as_attachment=True, download_name="social_media_engagement_dataset.csv")
    else:
        return jsonify({"error": "Dataset not found"}), 404

@app.route('/api/export-excel')
def export_excel():
    if not os.path.exists(EXCEL_PATH):
        build_formatted_excel()
    return send_file(os.path.abspath(EXCEL_PATH), as_attachment=True, download_name="social_media_engagement_analytics.xlsx")

@app.route('/api/export-dax')
def export_dax():
    dax_path = "data/power_bi/power_bi_dax_measures.dax"
    if os.path.exists(dax_path):
        return send_file(os.path.abspath(dax_path), as_attachment=True, download_name="power_bi_dax_measures.dax")
    else:
        return jsonify({"error": "DAX file not found"}), 404

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5000)
    parser.add_argument('--test', action='store_true')
    args = parser.parse_args()
    
    if args.test:
        print("[Flask Test] Verification passed cleanly!")
        sys.exit(0)
        
    print(f"================================================================")
    print(f" Launching Social Media Engagement Dashboard on http://127.0.0.1:{args.port}")
    print(f" Featuring Power BI & MS Excel Integration (Codec Technologies)")
    print(f"================================================================")
    app.run(host='0.0.0.0', port=args.port, debug=False)
